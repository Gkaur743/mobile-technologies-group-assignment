package com.example.mobile_tech_assignment2;

public class AnalysedImage {
    private String key;
    private String filename;
    private String reader;
    private String text;

    public AnalysedImage() {}

    public AnalysedImage(String key, String filename, String reader, String text) {
        this.key = key;
        this.filename = filename;
        this.reader = reader;
        this.text = text;
    }


    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getReader() {
        return reader;
    }

    public void setReader(String reader) {
        this.reader = reader;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
