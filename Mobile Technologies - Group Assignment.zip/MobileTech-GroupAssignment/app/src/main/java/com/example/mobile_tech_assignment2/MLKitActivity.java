package com.example.mobile_tech_assignment2;

import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.IOException;

public class MLKitActivity extends AppCompatActivity {
    private static final int REQUEST_PERMISSION = 3000;

    private Uri imageFileUri;
    private ImageView imageView;
    private TextView textViewReaderTitle;
    private TextView textViewInstruction;
    private Button buttonEditResult;
    private String readerType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_mlkit);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        imageView = findViewById(R.id.imageViewReader);
        textViewReaderTitle = findViewById(R.id.textViewReaderTitle);
        textViewInstruction = findViewById(R.id.textViewInstruction);
        buttonEditResult = findViewById(R.id.buttonEditResult);

        buttonEditResult.setVisibility(View.GONE);

        readerType = getIntent().getStringExtra("reader");

        if (readerType != null) {
            textViewReaderTitle.setText(readerType);

            switch (readerType) {
                case "Barcode Reader":
                    imageView.setImageResource(R.drawable.barcode);
                    break;
                case "Content Reader":
                    imageView.setImageResource(R.drawable.content);
                    break;
                case "Text Reader":
                    imageView.setImageResource(R.drawable.text);
                    break;
            }
        }

        buttonEditResult.setOnClickListener(v -> {
            Intent intent = new Intent(MLKitActivity.this, A5EditResultActivity.class);
            intent.putExtra("isNewRecord", true);
            intent.putExtra("readerName", readerType);
            intent.putExtra("mlKitResult", textViewInstruction.getText().toString());
            intent.putExtra("imageUri", imageFileUri.toString());
            startActivity(intent);
        });
    }

    private boolean checkPermission() {
        String permission = android.Manifest.permission.CAMERA;
        boolean granted = ContextCompat.checkSelfPermission(this, permission)
                == PackageManager.PERMISSION_GRANTED;
        if (!granted) {
            ActivityCompat.requestPermissions(this, new String[]{permission}, REQUEST_PERMISSION);
        }
        return granted;
    }

    public void openCamera(View view) {
        if (!checkPermission()) return;
        Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        imageFileUri = getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, new ContentValues());
        takePhotoIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageFileUri);
        activityResultLauncher.launch(takePhotoIntent);
    }

    public void loadImage(View view) {
        Intent galleryIntent = new Intent(
                Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        activityResultLauncher.launch(galleryIntent);
    }

    ActivityResultLauncher<Intent> activityResultLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    new ActivityResultCallback<ActivityResult>() {
                        @Override
                        public void onActivityResult(ActivityResult result) {
                            if (result.getResultCode() == RESULT_OK) {
                                if (result.getData() != null
                                        && result.getData().getData() != null) {
                                    imageFileUri = result.getData().getData();
                                }

                                imageView.setImageURI(imageFileUri);

                                textViewInstruction.setText("");
                                buttonEditResult.setVisibility(View.GONE);

                                try {
                                    InputImage image = InputImage.fromFilePath(
                                            getBaseContext(), imageFileUri);
                                    runMLKit(image);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                    textViewInstruction.setText("Error loading image.");
                                }
                            }
                        }
                    });

    private void runMLKit(InputImage image) {
        if (readerType == null) return;
        switch (readerType) {
            case "Barcode Reader":
                processImageFromBarcodeReader(image);
                break;
            case "Content Reader":
                processImageFromContentReader(image);
                break;
            case "Text Reader":
                processImageFromTextReader(image);
                break;
        }
    }

    private void processImageFromBarcodeReader(InputImage image) {
        BarcodeScannerOptions options = new BarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS).build();
        BarcodeScanner scanner = BarcodeScanning.getClient(options);
        scanner.process(image)
                .addOnSuccessListener(barcodes -> {
                    textViewInstruction.append(Html.fromHtml(
                            "<font color='navy'><b>Detected barcode:</b></font><br>",
                            Html.FROM_HTML_MODE_LEGACY));
                    String res = "";
                    for (Barcode barcode : barcodes) {
                        res = barcode.getRawValue();
                        textViewInstruction.append(res + "\n");
                    }
                    if (res.length() < 2) {
                        textViewInstruction.append(
                                "No barcode detected. Try a clearer barcode image.\n");
                    }
                    buttonEditResult.setVisibility(View.VISIBLE);
                })
                .addOnFailureListener(e ->
                        textViewInstruction.setText("Failed to process image."));
    }

    private void processImageFromContentReader(InputImage image) {
        ImageLabeler labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS);
        labeler.process(image)
                .addOnSuccessListener(labels -> {
                    if (labels.isEmpty()) {
                        textViewInstruction.append(
                                "No content detected in the image.\n");
                        buttonEditResult.setVisibility(View.VISIBLE);
                        return;
                    }
                    textViewInstruction.append(Html.fromHtml(
                            "<font color='navy'><b>Recognised image content:</b></font><br>",
                            Html.FROM_HTML_MODE_LEGACY));
                    int counter = 1;
                    for (ImageLabel label : labels) {
                        textViewInstruction.append(" " + counter + ". "
                                + label.getText() + " ("
                                + String.format("%.2f", label.getConfidence() * 100.0f)
                                + "% confidence)\n");
                        counter++;
                    }
                    buttonEditResult.setVisibility(View.VISIBLE);
                })
                .addOnFailureListener(e ->
                        textViewInstruction.setText("Failed to process image."));
    }

    private void processImageFromTextReader(InputImage image) {
        TextRecognizer recognizer = TextRecognition.getClient(
                TextRecognizerOptions.DEFAULT_OPTIONS);
        recognizer.process(image)
                .addOnSuccessListener(visionText -> {
                    textViewInstruction.append(Html.fromHtml(
                            "<font color='navy'><b>Extracted text:</b></font><br>",
                            Html.FROM_HTML_MODE_LEGACY));
                    String result = visionText.getText();
                    if (result.length() > 1) {
                        textViewInstruction.append(" " + result + "\n");
                    } else {
                        textViewInstruction.append(
                                "No readable text detected.\n");
                    }
                    buttonEditResult.setVisibility(View.VISIBLE);
                })
                .addOnFailureListener(e ->
                        textViewInstruction.setText("Failed to process image."));
    }
}
