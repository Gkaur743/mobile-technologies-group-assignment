package com.example.mobile_tech_assignment2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import android.widget.Toast;
public class A6ImageListActivity extends AppCompatActivity {

    private ListView listViewImages;
    private ImageListAdapter adapter;
    private final List<AnalysedImage> imageList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_a6_image_list);

        listViewImages = findViewById(R.id.listViewImages);
        Button buttonAdd = findViewById(R.id.buttonAdd);

        adapter = new ImageListAdapter(this, R.layout.list_item, imageList);
        listViewImages.setAdapter(adapter);

        // Open detail screen when a list item is selected.
        listViewImages.setOnItemClickListener((parent, view, position, id) -> {
            AnalysedImage item = imageList.get(position);
            Intent intent = new Intent(A6ImageListActivity.this, A7ImageDetailActivity.class);
            intent.putExtra("firebaseKey", item.getKey());
            intent.putExtra("readerName",  item.getReader());
            intent.putExtra("mlKitResult", item.getText());
            intent.putExtra("filename",    item.getFilename());
            startActivity(intent);
        });

        buttonAdd.setOnClickListener(v ->
                startActivity(new Intent(A6ImageListActivity.this, MainActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        // onResume not onCreate — list must refresh after returning from A5 or A7.

        loadFromFirebase();
    }


    private void loadFromFirebase() {
        FirebaseDatabase.getInstance().getReference("Storage")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        imageList.clear();
                        for (DataSnapshot child : snapshot.getChildren()) {
                            String key      = child.getKey();
                            String filename = child.child("filename").getValue(String.class);
                            String reader   = child.child("reader").getValue(String.class);
                            String text     = child.child("text").getValue(String.class);
                            imageList.add(new AnalysedImage(key, filename, reader, text));
                        }
                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        Toast.makeText(A6ImageListActivity.this,
                                "Failed to load images",
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
