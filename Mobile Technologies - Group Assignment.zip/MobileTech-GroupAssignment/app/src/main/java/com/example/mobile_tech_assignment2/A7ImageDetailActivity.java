package com.example.mobile_tech_assignment2;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.FirebaseDatabase;
import android.widget.Toast;

public class A7ImageDetailActivity extends AppCompatActivity {

    private String firebaseKey;
    private String readerName;
    private String mlKitResult;
    private String filename;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_a7_image_detail);

        TextView textViewReaderName  = findViewById(R.id.textViewReaderName);
        TextView textViewMlKitResult = findViewById(R.id.textViewMlKitResult);
        ImageView imageViewDetail    = findViewById(R.id.imageViewDetail);
        Button buttonEdit            = findViewById(R.id.buttonEdit);
        Button buttonDelete          = findViewById(R.id.buttonDelete);
        Button buttonCancel          = findViewById(R.id.buttonCancel);


        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            firebaseKey  = extras.getString("firebaseKey");
            readerName   = extras.getString("readerName");
            mlKitResult  = extras.getString("mlKitResult");
            filename     = extras.getString("filename");
        }

        textViewReaderName.setText(readerName);
        textViewMlKitResult.setText(mlKitResult);


        String path = getFilesDir() + "/" + filename + ".jpg";
        Bitmap bmp = BitmapFactory.decodeFile(path);
        if (bmp != null) {
            imageViewDetail.setImageBitmap(bmp);
        }

        buttonEdit.setOnClickListener(v -> onEdit());
        buttonDelete.setOnClickListener(v -> onDelete());
        buttonCancel.setOnClickListener(v -> onCancel());
    }

    private void onEdit() {

        Intent intent = new Intent(A7ImageDetailActivity.this, A5EditResultActivity.class);
        intent.putExtra("isNewRecord",  false);
        intent.putExtra("firebaseKey",  firebaseKey);
        intent.putExtra("readerName",   readerName);
        intent.putExtra("mlKitResult",  mlKitResult);
        intent.putExtra("imageUri",     getFilesDir() + "/" + filename + ".jpg");
        startActivity(intent);
        finish();
    }

    private void onDelete() {
        // Delete selected item from Firebase.
        FirebaseDatabase.getInstance().getReference("Storage")
                .child(firebaseKey)
                .removeValue()
                .addOnSuccessListener(unused -> {
                    Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(A7ImageDetailActivity.this, A6ImageListActivity.class));
                    finish();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show()
                );
    }

    private void onCancel() {

        startActivity(new Intent(A7ImageDetailActivity.this, A6ImageListActivity.class));
        finish();
    }
}
