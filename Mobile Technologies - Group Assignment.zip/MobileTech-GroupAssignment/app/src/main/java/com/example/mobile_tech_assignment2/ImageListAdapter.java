package com.example.mobile_tech_assignment2;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;
// Adapter used to display analysed images in the list view.
public class ImageListAdapter extends ArrayAdapter<AnalysedImage> {

    private final List<AnalysedImage> items;

    public ImageListAdapter(@NonNull Context context, int resource,
                            @NonNull List<AnalysedImage> objects) {
        super(context, resource, objects);
        items = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext())
                    .inflate(R.layout.list_item, parent, false);
        }

        AnalysedImage item = items.get(position);

        TextView textView = convertView.findViewById(R.id.textViewListItem);
        textView.setText(item.getText());

        ImageView imageView = convertView.findViewById(R.id.imageViewListItem);
        String path = getContext().getFilesDir() + "/" + item.getFilename() + ".jpg";
        Bitmap bmp = BitmapFactory.decodeFile(path);
        if (bmp != null) {
            imageView.setImageBitmap(bmp);
        } else {
            imageView.setImageResource(android.R.drawable.ic_menu_gallery);
        }

        if (position % 2 == 0) {
            convertView.setBackgroundColor(Color.WHITE);
        } else {
            convertView.setBackgroundColor(Color.LTGRAY);
        }

        return convertView;
    }
}
