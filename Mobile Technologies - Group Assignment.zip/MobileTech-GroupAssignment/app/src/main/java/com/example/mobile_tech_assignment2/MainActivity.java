package com.example.mobile_tech_assignment2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageView imageViewBarcode = findViewById(R.id.imageViewBarcode);
        imageViewBarcode.setOnClickListener(v -> openMLKitActivity("Barcode Reader"));

        ImageView imageViewContent = findViewById(R.id.imageViewContent);
        imageViewContent.setOnClickListener(v -> openMLKitActivity("Content Reader"));

        ImageView imageViewText = findViewById(R.id.imageViewText);
        imageViewText.setOnClickListener(v -> openMLKitActivity("Text Reader"));

        Button buttonList = findViewById(R.id.buttonListOfAnalysedImages);
        buttonList.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, A6ImageListActivity.class));
        });
    }

    private void openMLKitActivity(String readerType) {
        Intent intent = new Intent(MainActivity.this, MLKitActivity.class);
        intent.putExtra("reader", readerType);
        startActivity(intent);
    }
}
