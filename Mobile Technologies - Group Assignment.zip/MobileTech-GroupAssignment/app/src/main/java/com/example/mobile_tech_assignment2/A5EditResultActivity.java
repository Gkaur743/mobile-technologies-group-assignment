package com.example.mobile_tech_assignment2;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import android.widget.Toast;

// Activity for editing and saving analysed image results.
public class A5EditResultActivity extends AppCompatActivity {

    private EditText editTextReaderName;
    private EditText editTextMlKitResult;
    private TextView textViewResultHeader;
    private ImageView imageViewResult;
    private String resultHeader = "";

    private boolean isNewRecord;
    private String firebaseKey;
    private String imageUriString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_a5_edit_result);

        editTextReaderName   = findViewById(R.id.editTextReaderName);
        editTextMlKitResult  = findViewById(R.id.editTextMlKitResult);
        textViewResultHeader = findViewById(R.id.textViewResultHeader);
        imageViewResult      = findViewById(R.id.imageViewResult);
        Button buttonSave   = findViewById(R.id.buttonSave);

        // Retrieve data passed from previous activity.
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            isNewRecord    = extras.getBoolean("isNewRecord", true);
            firebaseKey    = extras.getString("firebaseKey");
            imageUriString = extras.getString("imageUri");

            editTextReaderName.setText(extras.getString("readerName"));

            // Split result header from editable ML Kit result text.
            String fullResult = extras.getString("mlKitResult", "");
            int firstNewline = fullResult.indexOf('\n');
            if (firstNewline != -1) {
                resultHeader = fullResult.substring(0, firstNewline).trim();
                editTextMlKitResult.setText(fullResult.substring(firstNewline).trim());
            } else {
                editTextMlKitResult.setText(fullResult);
            }
            textViewResultHeader.setText(resultHeader);

            if (imageUriString != null) {
                imageViewResult.setImageURI(Uri.parse(imageUriString));
            }
        }

        buttonSave.setOnClickListener(v -> onSave());
    }

    private void onSave() {
        String readerName  = editTextReaderName.getText().toString().trim();
        String mlKitResult = editTextMlKitResult.getText().toString().trim();

        if (isNewRecord) {
            saveNewRecord(readerName, mlKitResult);
        } else {
            updateExistingRecord(readerName, mlKitResult);
        }
    }

    // New record path: generate filename, save image, push to Firebase
    private void saveNewRecord(String readerName, String mlKitResult) {
        // Timestamp as filename - unique enough, and we control both ends of this chain
        String filename = String.valueOf(System.currentTimeMillis());

        saveImageToInternalStorage(filename);

        DatabaseReference db = FirebaseDatabase.getInstance().getReference("Storage");
        String key = db.push().getKey();

        HashMap<String, String> data = new HashMap<>();
        data.put("filename", filename);
        data.put("reader", readerName);
        data.put("text", mlKitResult);

        // Save new record to Firebase database.
        db.child(key).setValue(data).addOnSuccessListener(unused -> openImageList());
    }

    // Update existing Firebase record.
    private void updateExistingRecord(String readerName, String mlKitResult) {
        DatabaseReference db = FirebaseDatabase.getInstance()
                .getReference("Storage")
                .child(firebaseKey);

        db.child("reader").setValue(readerName);
        db.child("text").setValue(mlKitResult)
                .addOnSuccessListener(unused -> openImageList());
    }

    private void saveImageToInternalStorage(String filename) {
        try {
            Bitmap bitmap = MediaStore.Images.Media.getBitmap(
                    getContentResolver(), Uri.parse(imageUriString));
            FileOutputStream fos = openFileOutput(filename + ".jpg", MODE_PRIVATE);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos);
            fos.close();
        } catch (IOException e) {
            Toast.makeText(this,
                    "Failed to save image",
                    Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    private void openImageList() {
        startActivity(new Intent(A5EditResultActivity.this, A6ImageListActivity.class));
        finish();
    }
}
